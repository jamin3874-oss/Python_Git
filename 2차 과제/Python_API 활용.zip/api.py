import os
import json
import sys
import argparse
import datetime
import requests 
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")
kakao_key = os.getenv("KAKAO_REST_API_KEY")

if api_key is None or kakao_key is None:
    print("[오류] API 키가 설정되지 않았습니다.")
    print("'.env' 파일에 GEMINI_API_KEY, KAKAO_REST_API_KEY 값을 설정해주세요.")
    sys.exit(1)

url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key={api_key}"

# Gemini API
gemini_headers = {
    "Content-Type": "application/json"
}

# Kakao Map API 
kakao_headers = {
    "Authorization": f"KakaoAK {kakao_key}"
}

# --- CLI 입력받기 ---
parser = argparse.ArgumentParser()
parser.add_argument("--date", required=True)
args = parser.parse_args()

try:
    datetime.datetime.strptime(args.date, "%Y-%m-%d")
except ValueError:
    print("날짜 형식이 올바르지 않습니다. 예: 2026-03-15")
    print('사용법: python api.py --date "YYYY-MM-DD"')
    sys.exit(1)

date = args.date
errors = []

def call_gemini(user_prompt):
    body = {
        "contents": [
            {"parts": [{"text": user_prompt}]}
        ]
    }
    response = requests.post(url, headers=gemini_headers, json=body)
    data = response.json()
    text = data["candidates"][0]["content"]["parts"][0]["text"]
    return text

prompt = f"""
{date}에 여행하기 좋은 국내(대한민국) 여행지 1곳을 추천해줘.
아래 JSON 형식으로만 답하고, 다른 설명은 절대 붙이지 마.

{{
    "recommended_city": "지역명",
    "weather": "그 시기 날씨 요약",
    "events":["행사1", "행사2"],
    "reason": "추천 이유"
}}
"""

# 1) Gemini 요청 보내기 (JSON 파싱 실패 시 최대 1회 재시도)
current_prompt = prompt
rec = None

for attempt in range(2):
    answer_text = call_gemini(current_prompt)

    try:
        rec = json.loads(answer_text)
        break
    except json.JSONDecodeError:
        print(f"[경고] JSON 파싱 실패 (시도 {attempt + 1}회) - 재시도합니다.")
        errors.append({"step": "llm_recommendation", "type": "JSON_PARSE_ERROR", "message": f"시도 {attempt + 1}회 파싱 실패"})
        current_prompt = "반드시 순수 JSON 형식으로만, 설명 없이 다시 출력해줘.\n\n" + prompt

if rec is None:
    print("[오류] LLM 응답을 JSON으로 파싱하는 데 실패했습니다.")
    sys.exit(1)

print(answer_text)
print("---")
print(type(rec))
print(rec["recommended_city"])

# 2) 추천받은 도시로 Kakao 맛집 검색
city = rec["recommended_city"]

kakao_url = "https://dapi.kakao.com/v2/local/search/keyword.json"

params = {
    "query": f"{city} 맛집"
}

kakao_response = requests.get(kakao_url, headers=kakao_headers, params=params)

print("---")
print(kakao_response.status_code)

restaurants = []

if kakao_response.status_code == 200:
    kakao_data = kakao_response.json()
    documents = kakao_data["documents"]

    if len(documents) == 0:
        errors.append({"step": "place_search", "type": "EMPTY_RESULT", "message": f"'{city} 맛집' 검색 결과 0건"})

    for doc in documents[:5]:
        restaurant = {
            "name": doc["place_name"],
            "address": doc["road_address_name"],
            "category": doc["category_name"],
            "url": doc["place_url"],
            "x": doc["x"],
            "y": doc["y"]
        }
        restaurants.append(restaurant)
else:
    print("[경고] 맛집 검색 실패 (상태 코드:", kakao_response.status_code, ") - 맛집 없음으로 처리합니다.")
    errors.append({"step": "place_search", "type": "AUTH_ERROR", "message": f"HTTP {kakao_response.status_code}"})

print(json.dumps(restaurants, ensure_ascii=False, indent=2))

report_prompt = f"""
아래 데이터를 참고해서 여행 리포트를 Makrdown으로 작성해줘.

추천정보:
{json.dumps(rec, ensure_ascii=False)}

맛집목록:
{json.dumps(restaurants, ensure_ascii=False)}

오류목록:
{json.dumps(errors, ensure_ascii=False)}

다음 섹션을 포함해서 작성해:
# {date} 국내 여행 추천 리포트
## 추천 지역
## 추천 이유
## 날씨 요약
## 행사/축제
## 맛집 추천 (맛집목록이 비어있으면 절대 다른 맛집을 지어내지 말고, 반드시 "데이터 없음"이라고만 표기해)
## 1일 일정 제안
## 오류 요약(errors) (오류목록이 비어있으면 "없음"이라고만 표기하고, 있으면 각 오류의 step과 message를 간단히 나열해)
"""

#print(report_prompt)
try:
    report_md = call_gemini(report_prompt)
except (KeyError, IndexError):
    print("[경고] 리포트 생성에 실패했습니다. 다시 시도합니다.")
    errors.append({"step": "llm_report", "type": "API_ERROR", "message": "리포트 생성 1차 실패, 재시도함"})
    report_md = call_gemini(report_prompt)

print("=== 최종 리포트 ===")
print(report_md)

os.makedirs("results", exist_ok=True)
print("results 폴더 생성 완료 (또는 이미 있음)")

raw_data = {
    "date": date,
    "recommendation": rec,
    "restaurants": restaurants,
    "errors": errors
}

json_path = os.path.join("results", f"{date}_travel_data.json")

with open(json_path, "w", encoding="utf-8") as f:
    json.dump(raw_data, f, ensure_ascii=False, indent=2)

print("저장 완료:", json_path)

md_path = os.path.join("results", f"{date}_travel_plan.md")

with open(md_path, "w", encoding="utf-8") as f:
    f.write(report_md)

print("저장 완료:", md_path)