import argparse
import datetime
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--date", required=True)

args = parser.parse_args()

try:
    datetime.datetime.strptime(args.date, "%Y-%m-%d")
    print("날짜 형식이 올바릅니다:", args.date)
except ValueError:
    print("날짜 형식이 올바르지 않습니다. 예: 2026-03-15")
    print('사용법: python api.py --date "YYYY-MM-DD"')
    sys.exit(1)