import os
import requests
from dotenv import load_dotenv

def check_models():
    load_dotenv()
    api_key = os.getenv("OPENAI_API_KEY")
    
    if not api_key:
        print("❌ OPENAI_API_KEY가 설정되지 않았습니다.")
        return

    # Codyssey 모델 확인용 엔드포인트
    url = "https://copa.codyssey.kr/v1/models"
    headers = {
        "Authorization": f"Bearer {api_key}"
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        data = response.json()
        print("✅ Codyssey 사용 가능한 모델 목록:")
        for model in data.get("data", []):
            print(f"- {model.get('id')}")
            
    except requests.exceptions.RequestException as e:
        print(f"❌ 모델 조회 실패: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"에러 상세 내용: {e.response.text}")

if __name__ == "__main__":
    check_models()
