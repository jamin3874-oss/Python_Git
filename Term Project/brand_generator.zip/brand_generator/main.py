import os
import sys
import json
from dotenv import load_dotenv

# 모듈 폴더에서 실제 생성한 함수들을 가져옵니다.
try:
    from modules.input_handler import load_brief
    from modules.llm_engine import generate_brand_elements
    from modules.visualizer import create_color_palette_image
    from modules.logo_maker import generate_logo_images
except ImportError as e:
    print(f"❌ 모듈 임포트 에러: {e}")
    print("modules 폴더 내 파일 및 함수가 정상적으로 생성되었는지 확인해주세요.")
    sys.exit(1)

def main():
    # 1. 환경 변수 및 API 키 검증
    load_dotenv()
    
    # Codyssey API를 사용하므로 OPENAI_API_KEY를 확인하도록 수정했습니다.
    if not os.getenv("OPENAI_API_KEY"):
        print("❌ 환경 변수 오류: .env 파일에 OPENAI_API_KEY가 설정되지 않았습니다.")
        sys.exit(1)

    print("=== 🎨 AI 브랜드 디자인 자동화 CLI ===")
    
    # 2. 사용자 입력 처리
    brief_path = input("브리프 파일 경로를 입력하세요 (예: input/brief_sample.json): ").strip()
    if not brief_path:
        print("❌ 브리프 파일 경로는 필수입니다.")
        sys.exit(1)
        
    output_dir = input("출력 폴더 경로를 입력하세요 (기본값: ./output): ").strip()
    if not output_dir:
        output_dir = "./output"

    # 3. 브리프 파싱 및 출력 폴더 생성
    brief_data = load_brief(brief_path)
    os.makedirs(output_dir, exist_ok=True)
    print(f"\n✅ 브리프 로드 완료. [{output_dir}] 폴더에 결과를 저장합니다.\n")

    # 4. 브랜드 요소 생성 워크플로우 (목업 삭제 및 실제 API 호출 적용)
    brand_result = {}
    
    print("▶ [1/3] LLM을 통한 텍스트 브랜드 요소 생성 중...")
    try:
        # 실제 API 호출
        brand_result = generate_brand_elements(brief_data)
        print("  ✅ 텍스트 요소 생성 완료")
    except Exception as e:
        print(f"  ❌ 텍스트 생성 실패: {e}")
        sys.exit(1)

    print("▶ [2/3] 컬러 팔레트 시각화 이미지 생성 중...")
    try:
        if "colors" in brand_result:
            create_color_palette_image(brand_result["colors"], output_dir)
            print("  ✅ 컬러 팔레트 이미지 저장 완료")
    except Exception as e:
        print(f"  ❌ 컬러 팔레트 생성 실패: {e}")

    print("▶ [3/3] 이미지 생성 API를 통한 로고 시안 생성 중...")
    try:
        if "names" in brand_result and "colors" in brand_result:
            # 첫 번째 브랜드명을 로고 생성에 사용합니다.
            top_name = brand_result["names"][0]["name"]
            generate_logo_images(top_name, brief_data, brand_result["colors"], output_dir)
            print("  ✅ 로고 시안 이미지 저장 완료")
    except Exception as e:
        print(f"  ❌ 로고 생성 실패: {e}")

    # 5. 텍스트 결과물 JSON 저장
    result_json_path = os.path.join(output_dir, "brand_result.json")
    try:
        with open(result_json_path, 'w', encoding='utf-8') as f:
            json.dump(brand_result, f, ensure_ascii=False, indent=4)
        print(f"\n✅ 텍스트 결과물이 저장되었습니다: {result_json_path}")
    except Exception as e:
        print(f"\n❌ JSON 저장 실패: {e}")

    print("\n🎉 모든 브랜드 디자인 작업이 완료되었습니다!")

if __name__ == "__main__":
    main()
