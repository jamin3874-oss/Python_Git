import json
import sys

def load_brief(file_path):
    """JSON 브리프 파일을 읽어오고 필수 키값을 검증합니다."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 프로젝트 요구사항에 명시된 필수 필드 검증
        required_keys = ['industry', 'target', 'keywords']
        missing_keys = [key for key in required_keys if key not in data]
        if missing_keys:
            print(f"❌ 브리프 파일에 필수 항목이 누락되었습니다: {', '.join(missing_keys)}")
            sys.exit(1)
        
        return data
    except FileNotFoundError:
        print(f"❌ 파일을 찾을 수 없습니다: {file_path}")
        print("경로가 맞는지(예: input/brief_sample.json) 확인해주세요.")
        sys.exit(1)
    except json.JSONDecodeError:
        print("❌ 잘못된 형식의 JSON 파일입니다. 파일 구조를 확인해주세요.")
        sys.exit(1)
