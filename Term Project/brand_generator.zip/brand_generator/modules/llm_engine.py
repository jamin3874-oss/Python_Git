import os
import json
import requests

def generate_brand_elements(brief_data):
    """Codyssey API를 사용하여 JSON 형태의 브랜드 요소를 생성합니다."""
    api_key = os.getenv("OPENAI_API_KEY")
    url = "https://copa.codyssey.kr/v1/chat/completions"

    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    prompt = f"""
    당신은 20년 경력의 수석 브랜드 디렉터입니다. 
    다음 브리프를 바탕으로 브랜드 요소를 기획하고 반드시 정해진 JSON 형식으로만 답변해주세요.

    [브랜드 브리프]
    - 업종: {brief_data.get('industry')}
    - 타겟: {brief_data.get('target')}
    - 키워드: {', '.join(brief_data.get('keywords', []))}
    - 톤앤매너: {brief_data.get('tone', '기본')}
    - 추가요청: {brief_data.get('notes', '없음')}

    [필수 출력 JSON 구조]
    {{
        "names": [
            {{"name": "브랜드명1", "meaning": "의미1"}},
            {{"name": "브랜드명2", "meaning": "의미2"}},
            {{"name": "브랜드명3", "meaning": "의미3"}}
        ],
        "slogans": ["슬로건1", "슬로건2", "슬로건3"],
        "story": "브랜드 철학과 배경이 담긴 300자 내외의 스토리",
        "colors": {{
            "main": "#HEX코드",
            "sub": ["#HEX코드", "#HEX코드"]
        }}
    }}
    """

    data = {
        "model": "gpt-5.5", 
        "messages": [
            {"role": "system", "content": "You are a professional brand designer. You must strictly output valid JSON only. Do not use markdown code blocks like ```json."},
            {"role": "user", "content": prompt}
        ]
        # response_format 옵션을 완전히 제거했습니다.
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        response.raise_for_status() 
        
        result_json = response.json()
        result_text = result_json["choices"][0]["message"]["content"]
        
        # 모델이 마크다운(```json ... ```)을 포함해서 답변할 경우를 대비한 텍스트 정제
        result_text = result_text.strip()
        if result_text.startswith("```json"):
            result_text = result_text[7:]
        if result_text.startswith("```"):
            result_text = result_text[3:]
        if result_text.endswith("```"):
            result_text = result_text[:-3]
            
        return json.loads(result_text.strip())
        
    except requests.exceptions.RequestException as e:
        print(f"  ⚠️ LLM API 통신 에러: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"  에러 상세 내용: {e.response.text}")
        raise
    except json.JSONDecodeError:
        print("  ⚠️ LLM이 올바른 JSON 형식을 반환하지 않았습니다.")
        print(f"  반환된 텍스트:\n{result_text}")
        raise
