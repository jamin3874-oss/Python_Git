import os
import requests
import base64  # 이미지 디코딩을 위해 필수 추가

def generate_logo_images(top_name, brief_data, colors, output_dir, count=2):
    api_key = os.getenv("OPENAI_API_KEY")
    url = "https://copa.codyssey.kr/api/v1/images"

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    industry = brief_data.get('industry', 'business')
    main_color = colors.get('main', 'black')

    raw_prompt = (
        f"A professional minimalist vector logo for {industry} brand named '{top_name}'. "
        f"Main color is {main_color}. White background, flat vector style, clean."
    )

    for i in range(count):
        print(f"    - 로고 시안 {i+1} 생성 요청 중...")

        data = {
            "model": "gpt-image-2",
            "prompt": raw_prompt,
            "n": 1,
            "size": "1024x1024",
            # 핵심 해결책: URL 대신 Base64 형태의 텍스트 데이터로 요청
            "response_format": "b64_json"
        }

        try:
            # 1. 이미지 생성 API 호출
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()

            result_json = response.json()
            images_list = result_json.get("result", {}).get("images", [])

            if not images_list:
                print("    ⚠️ 서버에서 이미지 데이터를 반환하지 않았습니다.")
                continue

            image_data = images_list[0]

            # 2-A. Base64 텍스트로 데이터가 반환된 경우 (권한 에러 원천 차단)
            if "b64_json" in image_data:
                # 텍스트를 다시 이미지(바이트)로 변환
                img_bytes = base64.b64decode(image_data["b64_json"])
                
                save_path = os.path.join(output_dir, f"logo_{i+1}.png")
                with open(save_path, "wb") as handler:
                    handler.write(img_bytes)
                print(f"    ✅ 로고 {i+1} 저장 완료")

            # 2-B. 서버가 b64_json 옵션을 무시하고 끝내 URL만 반환하는 경우 (플랜 B)
            elif "url" in image_data:
                image_path = image_data["url"]
                image_url = f"https://copa.codyssey.kr{image_path}"

                # 봇(Bot) 접근을 막는 서버일 수 있으므로 브라우저인 척하는 헤더 추가
                fallback_headers = {
                    "Authorization": f"Bearer {api_key}",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                }
                
                img_response = requests.get(image_url, headers=fallback_headers)

                if img_response.status_code == 200:
                    save_path = os.path.join(output_dir, f"logo_{i+1}.png")
                    with open(save_path, "wb") as handler:
                        handler.write(img_response.content)
                    print(f"    ✅ 로고 {i+1} 저장 완료 (URL 다운로드 성공)")
                else:
                    print(f"    ⚠️ 이미지 다운로드 실패 (상태 코드: {img_response.status_code})")
                    
        except requests.exceptions.RequestException as e:
            print(f"    ⚠️ API 통신 에러: {e}")
        except Exception as e:
            print(f"    ⚠️ 에러 발생: {e}")
