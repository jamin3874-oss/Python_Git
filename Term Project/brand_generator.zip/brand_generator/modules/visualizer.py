import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def create_color_palette_image(colors, output_dir):
    """HEX 코드 딕셔너리를 받아 컬러 팔레트 이미지를 생성하고 저장합니다."""
    main_color = colors.get("main", "#000000")
    sub_colors = colors.get("sub", [])
    
    all_colors = [main_color] + sub_colors
    num_colors = len(all_colors)

    fig, ax = plt.subplots(figsize=(2 * num_colors, 3))
    ax.axis('off')

    for i, color in enumerate(all_colors):
        # 색상 박스 그리기
        rect = patches.Rectangle((i, 0), 1, 1, facecolor=color)
        ax.add_patch(rect)
        
        # HEX 코드 텍스트 추가
        ax.text(i + 0.5, -0.15, color, ha='center', va='top', fontsize=12, fontweight='bold')
        
        # 역할 레이블 (Main / Sub) 추가
        label = "Main Color" if i == 0 else f"Sub Color {i}"
        ax.text(i + 0.5, 1.05, label, ha='center', va='bottom', fontsize=10, color='#333333')

    ax.set_xlim(0, num_colors)
    ax.set_ylim(-0.2, 1.2)
    
    save_path = os.path.join(output_dir, "color_palette.png")
    plt.savefig(save_path, bbox_inches='tight', dpi=150)
    plt.close()
